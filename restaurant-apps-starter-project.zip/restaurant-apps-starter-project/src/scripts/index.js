import "regenerator-runtime"; /* for async await transpile */
import "../styles/main.css";

console.log("Hello Coders! :)");
const drawerToggle = document.querySelector(".drawer-toggle");
const drawer = document.querySelector(".drawer");

drawerToggle.addEventListener("click", function () {
  drawer.classList.toggle("open");
});
// Assuming you have access to the DATA.json file
const restaurantData = [
  {
    name: "Restaurant A",
    image: "path/to/imageA.jpg",
    city: "City A",
    rating: 4.5,
    description: "Description A",
  },
  {
    name: "Restaurant B",
    image: "path/to/imageB.jpg",
    city: "City B",
    rating: 4.2,
    description: "Description B",
  },
  // Add more restaurant data as needed
];

const restaurantList = document.querySelector(".restaurant-list");

restaurantData.forEach((restaurant) => {
  const restaurantItem = document.createElement("div");
  restaurantItem.classList.add("restaurant");

  restaurantItem.innerHTML = `
      <img src="${restaurant.image}" alt="${restaurant.name}">
      <h3>${restaurant.name}</h3>
      <p>City: ${restaurant.city}</p>
      <p>Rating: ${restaurant.rating}</p>
      <p>Description: ${restaurant.description}</p>
    `;

  restaurantList.appendChild(restaurantItem);
});

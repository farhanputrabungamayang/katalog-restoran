import "regenerator-runtime"; /* for async await transpile */
import "../styles/main.css";

console.log("Hello Coders! :)");
// JavaScript function to toggle menu visibility
function toggleMenu() {
  const menu = document.querySelector('.menu');
  menu.classList.toggle('show');
}

// Event listener for hamburger button
document.getElementById('hamburger').addEventListener('click', toggleMenu);
const restaurantList = document.querySelector('.restaurant-list');

restaurantData.forEach(restaurant => {
  const restaurantItem = document.createElement('div');
  restaurantItem.classList.add('restaurant');

  restaurantItem.innerHTML = `
    <img src="${restaurant.image}" alt="${restaurant.name}">
    <h3>${restaurant.name}</h3>
    <p>City: ${restaurant.city}</p>
    <p>Rating: ${restaurant.rating}</p>
    <p>Description: ${restaurant.description}</p>
  `;

  restaurantList.appendChild(restaurantItem);
});